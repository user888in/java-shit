package com.shop.demo.repository;

import com.shop.demo.model.Order;
import com.shop.demo.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUser_Id(Long userId); // navigate through the user relationship
    List<Order> findByStatus(OrderStatus status);
    List<Order> findByUser_IdAndStatus(Long userId, OrderStatus status);
}
